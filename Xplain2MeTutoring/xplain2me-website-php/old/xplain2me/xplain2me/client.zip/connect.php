<?php 
//session_start();
$dbhost = 'localhost';
$dbuser = 'xplainme_dbuser';
$dbpass = 'Nb5gg8[O$)fU';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
mysql_select_db('xplainme_xplain2me');
?>
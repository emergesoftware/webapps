<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
   
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Xplain2me </title>

    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->

    <script type="text/javascript" src="script.js"></script>
</head>
<body>
    <div id="art-page-background-gradient"></div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
        <div class="art-sheet">
            <div class="art-sheet-tl"></div>
            <div class="art-sheet-tr"></div>
            <div class="art-sheet-bl"></div>
            <div class="art-sheet-br"></div>
            <div class="art-sheet-tc"></div>
            <div class="art-sheet-bc"></div>
            <div class="art-sheet-cl"></div>
            <div class="art-sheet-cr"></div>
            <div class="art-sheet-cc"></div>
            <div class="art-sheet-body">
                <div class="art-header">
                    <div class="art-header-jpeg"></div>
                    <div class="art-logo">
                        <h1 id="name-text" class="art-logo-name"><a href="#">Xplain2me</a></h1>
                        <div id="slogan-text" class="art-logo-text"></div>
                    </div>
                </div>
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                		<li>
                			<a href="home/index.php" class="active"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
                		</li>
                				
                		<li>
                			<a href="home/about.php"><span class="l"></span><span class="r"></span><span class="t">About</span></a>
                		</li>
                        <li>
                			<a href="home/contactus.php"><span class="l"></span><span class="r"></span><span class="t">Contact us</span></a>
                		</li>
                	</ul>
                </div>
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                    &nbsp;<div class="art-layout-cell art-content">
         <?php 
//session_start();
//session_destroy();
?>
  </p>
  <h1>Thank you for visting</h1>
  <p><a href="home/index.php">LOGIN</a></p>
                        <div class="art-post"></div>
                      </div>
                        <div class="art-layout-cell art-sidebar1" style="height: 555px">
                          <p>&nbsp;</p>
                          <p>&nbsp;</p>
                           
                            </div>
                        </div>
                    </div>
                </div>
                <div class="cleared"></div><div class="art-footer">
                    <div class="art-footer-t"></div>
                    <div class="art-footer-l"></div>
                    <div class="art-footer-b"></div>
                    <div class="art-footer-r"></div>
                    <div class="art-footer-body">
                      <div class="art-footer-text">
                          <p><span class="footer"><a href="home/About us.php"><strong>About us</strong></a><strong> | <a href="home/contact.php">Contact us</a> | <a href="home/siteMap.php">Sitemap</a></strong></span><br />
                                Copyright &copy; 2012 ---. All Rights Reserved.</p>
                        </div>
                		<div class="cleared"></div>
                    </div>
                </div>
        		<div class="cleared"></div>
            </div>
        </div>
        <div class="cleared"></div>
        <p class="art-page-footer">&nbsp;</p>
    </div>
    
</body>
</html>
